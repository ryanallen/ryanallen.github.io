The Voynich glyph map
=====================

Every word and letter of the Voynich manuscript (Yale, Beinecke MS 408) traced so
far, tied to the pixels of Yale's page photographs. Made 22 November 2026 by Ryan Allen,
https://ryanallen.com/voynich/research.html. It's a snapshot: the tracing goes on
at https://ryanallen.com/voynich/ and I remake this download as it does.

READ THIS FIRST: HOW FAR TO TRUST EACH LETTER
---------------------------------------------
Most of this map is machine work. Every word and letter has a `trust` column, and
only the first two levels have been checked by a person:

  owner-traced      333 words  I traced or fixed it by hand, or approved a volunteer's tracing from the site
  owner-answered    127 words  I settled its reading by hand, answering a question about a hard word
  auto-placed     14049 words  AI placed it from the page's ink, letter by letter. No person has checked it
  auto-checked     9098 words  The text reader drafted it and AI looked it over. No person has checked it
  auto             5629 words  The text reader drafted it. No one has checked it

For anything you'd publish, start from owner-traced and owner-answered and treat
the rest as drafts. `held_out` is yes for words kept out of the text reader's
training so it could be scored on them.

FILES
-----
words.tsv    one row per word: word_id (locus.wN, as in the Zandbergen-Landini
             transliteration ZL 3b), page, reading (EVA letters, space-separated),
             trust, held_out, image, the word's box (box_*, from the Voynichese
             project's boxes fitted to Yale's images), the bounding box of its
             traced ink (ink_*), ink and stray pixel counts, and a note.
letters.tsv  one row per letter: word_id, letter (1 = first), eva, trust, image,
             pixel count, bounding box (x0 y0 x1 y1, x1/y1 exclusive), centroid.
pages.tsv    each Yale image used: size, SHA-256, IIIF canvas and full-size URL.
trust.tsv    the trust levels with word and letter counts.
masks/<page>.npz  every traced pixel (NumPy): arrays x, y, word (index into
             `words`), letter (0-based index in the word's reading; -1 is ink in
             the word's area given to no letter), image (index into `images`;
             1 only on spreads joined from two photographs).

Coordinates are pixels of Yale's full-size JPEG named in `image`
(IIIF .../full/full/0/default.jpg), x to the right, y down, origin top left.
A letter name joined with + (c+t+h) is one glyph written over another.

    import numpy as np
    m = np.load("masks/f1r.npz")
    i = list(m["words"]).index("f1r.1.w1")
    sel = m["word"] == i
    xs, ys, letter = m["x"][sel], m["y"][sel], m["letter"][sel]

CREDITS AND LICENSE
-------------------
The map: CC BY 4.0, credit "Ryan Allen, Voynich glyph map, ryanallen.com/voynich".
Tracers on the site who asked to be named: nablator, christopear, Shlomo1, EMZS, powder9.
Transliteration: Zandbergen-Landini ZL 3b (CC0), voynich.nu.
Word boxes: the Voynichese project (Apache 2.0), fitted to Yale's images.
Images: Cipher manuscript (Voynich manuscript), Beinecke Rare Book and Manuscript
Library, Yale University. No images are included; fetch them from Yale by the
URLs in pages.tsv.
